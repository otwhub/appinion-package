//
//  appinion.h
//  appinion
//
//  Created by OTW, Lda on 18/11/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for appinion.
FOUNDATION_EXPORT double appinionVersionNumber;

//! Project version string for appinion.
FOUNDATION_EXPORT const unsigned char appinionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <appinion/PublicHeader.h>


